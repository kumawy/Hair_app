import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/provider_hairstyle.dart';
class HaircutCard extends ConsumerStatefulWidget {
  const HaircutCard({super.key});

  @override
  ConsumerState<HaircutCard> createState() => _HaircutCardState();
}

class _HaircutCardState extends ConsumerState<HaircutCard> {
  final hairstyleByIdProvider = Provider.family<Hairstyle?, String>((ref, id) {
    final hairstyles = ref.watch(hairstylesNotifierProvider).valueOrNull;
    return hairstyles?.firstWhereOrNull((h) => h.id == id);
  });
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Haircut Card'),
      ),
      body:
    );
  }
}
